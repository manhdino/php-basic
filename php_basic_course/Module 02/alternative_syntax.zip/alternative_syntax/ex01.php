<?php
/*
 * 1. Toán tử 3 ngôi
 * 2. Cú pháp thay thế if
 * 3. Cú pháp thay thế for
 * 4. Cú pháp thay thế while
 * 5. Cú pháp thay thế foreach
 * */
$number = 10;
//if ($number == 10){
//    echo 'Bạn đủ tuổi';
//}else{
//    echo 'Bạn không đủ tuổi';
//}
//echo '<br/>';
//1. Toán tử 3 ngôi
//echo $number==10?'Bạn đủ tuổi':'Bạn không đủ tuổi';
$printStr = $number==10?'Bạn đủ tuổi':'Bạn không đủ tuổi';
//var_dump($printStr);

/*
 * Cú pháp:
 * bieu_thuc_dieu_kien?ket_qua_dung:ket_qua_sai
 *
 * Lưu ý:
 * - Toán tử 3 ngôi phải gắn 1 biểu thức (Gán, echo)
 * - Luôn luôn phải có kết quả sai
 * (Nếu không muốn hiển thị thì để là: false, null, trống (''))
 * */

$printStr = $number==10?'Bạn đủ tuổi':null;
//echo $printStr;

//2. Cú pháp thay thế câu lệnh if

if ($number==10){
    ?>
    <h3>Tiêu đề 1</h3>
    <h4>Tiêu đề 2</h4>
    <p>Nội dung đoạn văn</p>
    <?php
}else{
    ?>
    <p>Không hợp lệ</p>
    <?php
}

if ($number==10):
?>
    <h3>Tiêu đề 1</h3>
    <h4>Tiêu đề 2</h4>
    <p>Nội dung đoạn văn</p>
<?php
else:
?>
    <p>Không hợp lệ</p>
<?php
endif;
